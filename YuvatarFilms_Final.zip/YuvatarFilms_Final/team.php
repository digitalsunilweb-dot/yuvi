<?php
$page_title="Team | Yuvatar Films";
include "includes/header.php";
?>

<section class="page-hero">
<div class="container">
<h1>Our Team</h1>
<p>The creative minds behind Yuvatar Films.</p>
</div>
</section>

<section class="section">
<div class="container">

<div class="cards team-grid">

<div class="card team-card">
<img src="assets/images/team/member.jpg" alt="Team Member">
<h3>Team Member Name</h3>
<p>Designation</p>
</div>

<div class="card team-card">
<img src="assets/images/team/member.jpg" alt="Team Member">
<h3>Creative Team</h3>
<p>Production Department</p>
</div>

</div>

</div>
</section>

<?php include "includes/footer.php"; ?>