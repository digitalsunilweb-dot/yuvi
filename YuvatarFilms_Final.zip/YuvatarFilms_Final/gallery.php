<?php
$page_title="Gallery | Yuvatar Films";
include "includes/header.php";
?>

<section class="page-hero">
<div class="container">
<h1>Gallery</h1>
<p>Behind the scenes and cinematic moments from Yuvatar Films.</p>
</div>
</section>

<section class="section">
<div class="container">

<div class="gallery-grid">

<a href="gallery-album.php" class="album-card">
<img src="assets/images/gallery/cover.jpg" alt="Gallery Album">
<div>
<h3>Production Album</h3>
<p>Film Shoot</p>
</div>
</a>

<a href="gallery-album.php" class="album-card">
<img src="assets/images/gallery/cover.jpg" alt="Gallery Album">
<div>
<h3>Behind The Scenes</h3>
<p>BTS Moments</p>
</div>
</a>

</div>

</div>
</section>

<?php include "includes/footer.php"; ?>