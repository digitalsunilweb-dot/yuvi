<?php
$page_title="About Yuvatar Films";
include "includes/header.php";
?>

<section class="page-hero about-hero">
<div class="container">
<h1>About Yuvatar Films</h1>
<p>Creating cinematic stories with passion, creativity and visual excellence.</p>
</div>
</section>

<section class="section">
<div class="container">
<h2 class="section-title">Who We Are</h2>
<p class="large-text">
Yuvatar Films is a film production and creative media company focused on cinematic storytelling,
brand films, documentaries, photography and visual experiences.
</p>
</div>
</section>

<section class="section dark-section">
<div class="container cards">
<div class="card">
<h3>Our Vision</h3>
<p>To create meaningful visual stories that connect with audiences.</p>
</div>

<div class="card">
<h3>Our Mission</h3>
<p>Deliver professional cinematic production solutions for brands, artists and organisations.</p>
</div>
</div>
</section>

<section class="section">
<div class="container">
<h2 class="section-title">Our Creative Approach</h2>
<p>
From concept development to final delivery, we focus on storytelling,
visual quality and creative execution.
</p>
</div>
</section>

<section class="section final-cta">
<div class="container">
<h2>Let's Create Your Next Story</h2>
<a href="contact.php" class="btn-primary">Start A Project</a>
</div>
</section>

<?php include "includes/footer.php"; ?>