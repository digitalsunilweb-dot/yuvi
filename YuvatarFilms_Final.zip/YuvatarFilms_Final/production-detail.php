<?php
$page_title="Production Detail | Yuvatar Films";
include "includes/header.php";
?>

<section class="production-banner">

<div class="container">

<h1>Production Title</h1>

<p class="status">
COMING SOON
</p>

</div>

</section>


<section class="section">

<div class="container">

<h2 class="section-title">Synopsis</h2>

<p>
Production synopsis will be displayed here.
This section will become CMS driven after backend integration.
</p>


<div class="details-grid">

<div>
<h3>Director</h3>
<p>Name</p>
</div>

<div>
<h3>Producer</h3>
<p>Name</p>
</div>

<div>
<h3>Language</h3>
<p>Hindi</p>
</div>

<div>
<h3>Location</h3>
<p>Jamshedpur</p>
</div>

</div>


<h2 class="section-title">Trailer</h2>

<div class="video-box">
YouTube Trailer Preview
</div>


<h2 class="section-title">Gallery</h2>

<div class="gallery-placeholder">
Production Images
</div>


</div>

</section>


<?php include "includes/footer.php"; ?>