Yuvatar Films Migration Package

Hostinger Deployment:
1. Upload files to public_html
2. Create MySQL database
3. Import database/yuvatarfilms.sql
4. Update database credentials
5. Enable SSL
6. Test admin login and frontend pages

Do not upload without taking existing website backup.
