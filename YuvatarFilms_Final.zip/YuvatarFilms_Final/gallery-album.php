<?php
$page_title="Gallery Album | Yuvatar Films";
include "includes/header.php";
?>

<section class="page-hero">
<div class="container">
<h1>Production Album</h1>
<p>Cinematic images and production moments.</p>
</div>
</section>

<section class="section">
<div class="container">

<div class="masonry-gallery">

<img src="assets/images/gallery/image1.jpg" alt="Gallery Image">
<img src="assets/images/gallery/image2.jpg" alt="Gallery Image">
<img src="assets/images/gallery/image3.jpg" alt="Gallery Image">
<img src="assets/images/gallery/image4.jpg" alt="Gallery Image">

</div>

</div>
</section>

<?php include "includes/footer.php"; ?>