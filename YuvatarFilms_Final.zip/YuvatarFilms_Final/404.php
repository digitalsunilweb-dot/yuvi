<?php
$page_title="404 | Yuvatar Films";
include "includes/header.php";
?>

<section class="page-hero">
<div class="container">
<h1>Page Not Found</h1>
<p>The page you are looking for does not exist.</p>
<a href="index.php" class="btn-primary">Back To Home</a>
</div>
</section>

<?php include "includes/footer.php"; ?>