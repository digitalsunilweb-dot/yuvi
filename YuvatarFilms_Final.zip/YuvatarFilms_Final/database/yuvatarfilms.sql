CREATE TABLE admin_users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) UNIQUE NOT NULL,
 username VARCHAR(100) UNIQUE NOT NULL,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('Super Admin','Content Manager') DEFAULT 'Content Manager',
 status TINYINT DEFAULT 1,
 last_login DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE productions (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(255) NOT NULL,
 slug VARCHAR(255) UNIQUE,
 short_description TEXT,
 synopsis TEXT,
 category VARCHAR(100),
 status VARCHAR(50),
 poster VARCHAR(255),
 banner VARCHAR(255),
 mobile_poster VARCHAR(255),
 youtube_url VARCHAR(255),
 release_date DATE NULL,
 production_year VARCHAR(10),
 duration VARCHAR(50),
 language VARCHAR(100),
 location VARCHAR(150),
 director VARCHAR(150),
 producer VARCHAR(150),
 writer VARCHAR(150),
 cinematographer VARCHAR(150),
 editor VARCHAR(150),
 music VARCHAR(150),
 cast TEXT,
 client_brand VARCHAR(150),
 production_company VARCHAR(150),
 featured TINYINT DEFAULT 0,
 display_order INT DEFAULT 0,
 seo_title VARCHAR(255),
 meta_description TEXT,
 canonical_url VARCHAR(255),
 indexing TINYINT DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE production_media (
 id INT AUTO_INCREMENT PRIMARY KEY,
 production_id INT,
 file_path VARCHAR(255),
 caption TEXT,
 alt_text VARCHAR(255)
);

CREATE TABLE gallery_albums (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(255),
 slug VARCHAR(255),
 description TEXT,
 cover_image VARCHAR(255),
 related_production_id INT NULL,
 shoot_date DATE NULL,
 location VARCHAR(150),
 photographer_credit VARCHAR(150),
 featured TINYINT DEFAULT 0,
 status VARCHAR(50),
 seo_title VARCHAR(255),
 seo_description TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE gallery_images (
 id INT AUTO_INCREMENT PRIMARY KEY,
 album_id INT,
 image_path VARCHAR(255),
 caption TEXT,
 alt_text VARCHAR(255),
 credit VARCHAR(150),
 display_order INT DEFAULT 0
);

CREATE TABLE team_members (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150),
 designation VARCHAR(150),
 image VARCHAR(255),
 bio TEXT,
 links TEXT,
 display_order INT DEFAULT 0,
 status TINYINT DEFAULT 1
);

CREATE TABLE testimonials (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150),
 company VARCHAR(150),
 image VARCHAR(255),
 testimonial TEXT,
 display_order INT DEFAULT 0,
 status TINYINT DEFAULT 1
);

CREATE TABLE media_library (
 id INT AUTO_INCREMENT PRIMARY KEY,
 filename VARCHAR(255),
 filepath VARCHAR(255),
 file_type VARCHAR(50),
 file_size INT,
 alt_text VARCHAR(255),
 caption TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE site_settings (
 id INT AUTO_INCREMENT PRIMARY KEY,
 setting_key VARCHAR(100) UNIQUE,
 setting_value TEXT
);

CREATE TABLE admin_activity_logs (
 id INT AUTO_INCREMENT PRIMARY KEY,
 admin_id INT,
 action VARCHAR(255),
 module VARCHAR(100),
 ip_address VARCHAR(50),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
