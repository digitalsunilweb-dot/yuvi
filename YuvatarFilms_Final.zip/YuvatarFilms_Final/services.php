<?php
$page_title="Services | Yuvatar Films";
include "includes/header.php";
?>

<section class="page-hero">
<div class="container">
<h1>Our Services</h1>
<p>Cinematic production solutions for brands, artists and organisations.</p>
</div>
</section>

<section class="section">
<div class="container">

<div class="cards service-grid">

<div class="card"><h3>Cinematic Films</h3><p>Feature and short film production.</p></div>
<div class="card"><h3>Ad Films</h3><p>Creative advertising films for brands.</p></div>
<div class="card"><h3>Corporate Films</h3><p>Professional business storytelling.</p></div>
<div class="card"><h3>Documentaries</h3><p>Real stories with cinematic presentation.</p></div>
<div class="card"><h3>Music Videos</h3><p>Visual experiences for artists.</p></div>
<div class="card"><h3>Photography</h3><p>Professional photography solutions.</p></div>
<div class="card"><h3>Video Editing</h3><p>Editing and colour grading services.</p></div>
<div class="card"><h3>Social Media Content</h3><p>Creative digital content production.</p></div>

</div>

</div>
</section>

<section class="section dark-section">
<div class="container">
<h2 class="section-title">Production Workflow</h2>

<div class="cards">
<div class="card">Concept</div>
<div class="card">Pre Production</div>
<div class="card">Production</div>
<div class="card">Post Production</div>
</div>

</div>
</section>

<section class="section final-cta">
<div class="container">
<h2>Need A Professional Production Partner?</h2>
<a href="contact.php" class="btn-primary">Contact Us</a>
</div>
</section>

<?php include "includes/footer.php"; ?>