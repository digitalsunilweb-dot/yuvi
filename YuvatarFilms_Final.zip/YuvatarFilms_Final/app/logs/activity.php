<?php

function addActivityLog($pdo,$admin,$action,$module){

$stmt=$pdo->prepare(
"INSERT INTO admin_activity_logs
(admin_id,action,module,ip_address)
VALUES(?,?,?,?)"
);

$stmt->execute([
$admin,
$action,
$module,
$_SERVER['REMOTE_ADDR']
]);

}

?>