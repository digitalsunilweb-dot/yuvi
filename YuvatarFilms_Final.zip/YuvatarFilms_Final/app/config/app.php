<?php

define('APP_NAME', 'Yuvatar Films');

define('BASE_PATH', dirname(__DIR__,2));

define('UPLOAD_PATH', BASE_PATH.'/uploads/');

date_default_timezone_set('Asia/Kolkata');

?>