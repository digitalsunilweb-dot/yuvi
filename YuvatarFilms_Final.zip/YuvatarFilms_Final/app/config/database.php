<?php

class Database {

    private $host = 'localhost';
    private $db = 'yuvatarfilms';
    private $user = 'database_user';
    private $pass = 'database_password';

    public function connect(){

        try{

            $pdo = new PDO(
                "mysql:host=".$this->host.";dbname=".$this->db.";charset=utf8mb4",
                $this->user,
                $this->pass
            );

            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            return $pdo;

        }catch(PDOException $e){

            die("Database connection failed");

        }

    }

}

?>