<?php
$page_title="Yuvatar Films";
include "includes/db-data.php";

$productions=getProductions();
$gallery=getGalleryAlbums();
$team=getTeamMembers();

include "includes/header.php";
?>

<section class="hero">
<div class="container hero-content">

<h1>Stories That Move.<br>Visuals That Stay.</h1>

<p>
Cinematic films and creative visual production by Yuvatar Films.
</p>

<a href="contact.php" class="btn-primary">
Start A Project
</a>

</div>
</section>


<section class="section">
<div class="container">

<h2 class="section-title">
Featured Productions
</h2>

<div class="cards">

<?php foreach($productions as $item): ?>

<div class="card">

<img src="uploads/productions/<?=htmlspecialchars($item['poster'])?>">

<h3>
<?=htmlspecialchars($item['title'])?>
</h3>

<p>
<?=htmlspecialchars($item['status'])?>
</p>

</div>

<?php endforeach; ?>

</div>

</div>
</section>


<section class="section">

<div class="container">

<h2 class="section-title">
Our Team
</h2>

<div class="cards">

<?php foreach($team as $member): ?>

<div class="card">

<h3>
<?=htmlspecialchars($member['name'])?>
</h3>

<p>
<?=htmlspecialchars($member['designation'])?>
</p>

</div>

<?php endforeach; ?>

</div>

</div>

</section>


<?php include "includes/footer.php"; ?>