const header = document.getElementById("header");

window.addEventListener("scroll",()=>{
    if(window.scrollY > 50){
        header.classList.add("scrolled");
    }else{
        header.classList.remove("scrolled");
    }
});

const menuToggle=document.getElementById("menuToggle");
const navMenu=document.getElementById("navMenu");

if(menuToggle){
menuToggle.addEventListener("click",()=>{
navMenu.classList.toggle("active");
});
}