<?php
$page_title="Contact | Yuvatar Films";
include "includes/header.php";
?>

<section class="page-hero">
<div class="container">
<h1>Contact Yuvatar Films</h1>
<p>Let's discuss your next visual project.</p>
</div>
</section>

<section class="section">
<div class="container contact-layout">

<div>
<h2 class="section-title">Start A Project</h2>

<form class="contact-form">

<input type="text" placeholder="Name">

<input type="text" placeholder="Company">

<input type="email" placeholder="Email">

<input type="tel" placeholder="Phone">

<select>
<option>Select Service</option>
<option>Film Production</option>
<option>Ad Film</option>
<option>Corporate Film</option>
<option>Photography</option>
</select>

<select>
<option>Budget Range</option>
<option>Below 50K</option>
<option>50K - 2L</option>
<option>Above 2L</option>
</select>

<textarea placeholder="Project Details"></textarea>

<button class="btn-primary">
Submit Enquiry
</button>

</form>

</div>


<div class="contact-info">

<h3>Yuvatar Films</h3>
<p>Jamshedpur, Jharkhand</p>
<p>Email: info@yuvatarfilms.com</p>
<p>Phone: +91 8210810573</p>

</div>

</div>
</section>


<?php include "includes/footer.php"; ?>