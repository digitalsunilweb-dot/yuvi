<?php
$page_title="Productions | Yuvatar Films";
include "includes/header.php";
?>

<section class="page-hero">
<div class="container">
<h1>Our Productions</h1>
<p>Cinematic stories created with creativity and vision.</p>
</div>
</section>

<section class="section">
<div class="container">

<div class="filter-bar">
<button class="filter active">All</button>
<button class="filter">Feature Film</button>
<button class="filter">Documentary</button>
<button class="filter">Ad Film</button>
<button class="filter">Music Video</button>
</div>

<div class="cards production-grid">

<div class="production-card">
<div class="poster">
<img src="assets/images/productions/poster.jpg" alt="Production">
</div>
<div class="card-content">
<span>Feature Film</span>
<h3>Production Title</h3>
<p>Coming Soon</p>
<a href="production-detail.php" class="btn-secondary">View Details</a>
</div>
</div>


<div class="production-card">
<div class="poster">
<img src="assets/images/productions/poster.jpg" alt="Production">
</div>
<div class="card-content">
<span>Documentary</span>
<h3>Documentary Project</h3>
<p>Released</p>
<a href="production-detail.php" class="btn-secondary">View Details</a>
</div>
</div>


</div>

</div>
</section>

<?php include "includes/footer.php"; ?>