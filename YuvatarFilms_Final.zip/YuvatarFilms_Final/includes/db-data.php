<?php
require_once __DIR__."/../app/config/database.php";

function getProductions($limit = 6){

    $db = new Database();
    $pdo = $db->connect();

    $stmt = $pdo->prepare(
        "SELECT * FROM productions 
         WHERE status!='Draft'
         ORDER BY featured DESC,id DESC
         LIMIT ?"
    );

    $stmt->bindValue(1,$limit,PDO::PARAM_INT);
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_ASSOC);

}


function getGalleryAlbums($limit = 6){

    $db = new Database();
    $pdo = $db->connect();

    $stmt=$pdo->prepare(
        "SELECT * FROM gallery_albums 
        WHERE status='Published'
        ORDER BY id DESC
        LIMIT ?"
    );

    $stmt->bindValue(1,$limit,PDO::PARAM_INT);
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_ASSOC);

}


function getTeamMembers($limit = 6){

    $db = new Database();
    $pdo = $db->connect();

    $stmt=$pdo->prepare(
        "SELECT * FROM team_members
        WHERE status=1
        ORDER BY display_order ASC
        LIMIT ?"
    );

    $stmt->bindValue(1,$limit,PDO::PARAM_INT);
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_ASSOC);

}

?>