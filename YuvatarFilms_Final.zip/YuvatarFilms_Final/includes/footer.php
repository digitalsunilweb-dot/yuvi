<footer class="footer">

<div class="container footer-grid">

<div>
<h3>Yuvatar Films</h3>
<p>
Stories that move. Visuals that stay.
Film production and creative media company.
</p>
</div>

<div>
<h4>Services</h4>
<p>Films</p>
<p>Photography</p>
<p>Ad Films</p>
<p>Corporate Films</p>
</div>

<div>
<h4>Contact</h4>
<p>Jamshedpur, Jharkhand</p>
<p>info@yuvatarfilms.com</p>
<p>+91 8210810573</p>
</div>

</div>

<div class="copyright">
© <?= date("Y"); ?> Yuvatar Films. All Rights Reserved.
</div>

</footer>

<script src="assets/js/main.js"></script>
</body>
</html>