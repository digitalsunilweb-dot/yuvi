<?php
if (!isset($page_title)) {
    $page_title = "Yuvatar Films";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($page_title); ?></title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/responsive.css">
</head>
<body>

<header class="site-header" id="header">
<div class="container header-inner">

<a href="index.php" class="logo">
<img src="assets/images/logo.png" alt="Yuvatar Films">
</a>

<button class="menu-toggle" id="menuToggle">☰</button>

<nav class="nav-menu" id="navMenu">
<a href="index.php">Home</a>
<a href="about.php">About</a>
<a href="services.php">Services</a>
<a href="productions.php">Productions</a>
<a href="gallery.php">Gallery</a>
<a href="team.php">Team</a>
<a href="contact.php">Contact</a>
</nav>

<a href="contact.php" class="btn-primary">Start A Project</a>

</div>
</header>