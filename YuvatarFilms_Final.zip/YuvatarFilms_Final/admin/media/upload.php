<?php
require_once "../../app/middleware/auth.php";

function secureUpload($file){

    $allowed = ['jpg','jpeg','png','webp'];

    $ext = strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));

    if(!in_array($ext,$allowed)){
        return false;
    }

    $name = uniqid().".".$ext;

    move_uploaded_file(
        $file['tmp_name'],
        "../../uploads/".$name
    );

    return $name;
}

if($_POST && isset($_FILES['file'])){

    $uploaded = secureUpload($_FILES['file']);

    if($uploaded){
        echo "Upload successful";
    }

}

?>

<h1>Upload Media</h1>

<form method="post" enctype="multipart/form-data">

<input type="file" name="file">

<input name="alt_text" placeholder="Alt Text">

<input name="caption" placeholder="Caption">

<button>Upload</button>

</form>