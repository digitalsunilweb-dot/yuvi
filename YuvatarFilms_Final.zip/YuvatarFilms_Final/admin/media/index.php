<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

$db = new Database();
$pdo = $db->connect();

$media = $pdo->query("SELECT * FROM media_library ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Media Library</h1>

<a href="upload.php">Upload Media</a>

<table border="1" cellpadding="10">
<tr>
<th>File</th>
<th>Type</th>
<th>Size</th>
<th>Action</th>
</tr>

<?php foreach($media as $item): ?>
<tr>
<td><?=htmlspecialchars($item['filename'])?></td>
<td><?=htmlspecialchars($item['file_type'])?></td>
<td><?=htmlspecialchars($item['file_size'])?></td>
<td>
<a href="edit.php?id=<?=$item['id']?>">Edit</a>
<a href="delete.php?id=<?=$item['id']?>">Delete</a>
</td>
</tr>
<?php endforeach; ?>

</table>