<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$db=new Database();
$pdo=$db->connect();

$stmt=$pdo->prepare(
"INSERT INTO productions
(title,slug,short_description,category,status,youtube_url)
VALUES(?,?,?,?,?,?)"
);

$stmt->execute([
$_POST['title'],
$_POST['slug'],
$_POST['short_description'],
$_POST['category'],
$_POST['status'],
$_POST['youtube_url']
]);

header("Location:index.php");
exit;

}

?>

<h1>Add Production</h1>

<form method="post">

<input name="title" placeholder="Title" required>

<input name="slug" placeholder="Slug">

<textarea name="short_description"></textarea>

<input name="category" placeholder="Category">

<select name="status">
<option>Draft</option>
<option>Coming Soon</option>
<option>Released</option>
</select>

<input name="youtube_url" placeholder="YouTube URL">

<button>Add</button>

</form>