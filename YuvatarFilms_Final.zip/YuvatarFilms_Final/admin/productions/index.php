<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

$db = new Database();
$pdo = $db->connect();

$productions = $pdo->query("SELECT * FROM productions ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Productions</h1>

<a href="add.php">Add Production</a>

<table border="1" cellpadding="10">
<tr>
<th>Title</th>
<th>Status</th>
<th>Category</th>
<th>Action</th>
</tr>

<?php foreach($productions as $item): ?>

<tr>
<td><?= htmlspecialchars($item['title']) ?></td>
<td><?= htmlspecialchars($item['status']) ?></td>
<td><?= htmlspecialchars($item['category']) ?></td>
<td>
<a href="edit.php?id=<?= $item['id'] ?>">Edit</a>
<a href="delete.php?id=<?= $item['id'] ?>">Delete</a>
</td>
</tr>

<?php endforeach; ?>

</table>