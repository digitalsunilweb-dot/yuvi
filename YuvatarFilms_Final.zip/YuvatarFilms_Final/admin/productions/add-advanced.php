<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";
require_once "upload-helper.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$db=new Database();
$pdo=$db->connect();

$poster="";
$banner="";

if(isset($_FILES['poster'])){
$poster=uploadImage($_FILES['poster']);
}

if(isset($_FILES['banner'])){
$banner=uploadImage($_FILES['banner']);
}


$stmt=$pdo->prepare(
"INSERT INTO productions
(title,slug,short_description,synopsis,category,status,
poster,banner,youtube_url,release_date,director,producer,
featured,seo_title,meta_description)
VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
);


$stmt->execute([

$_POST['title'],
$_POST['slug'],
$_POST['short_description'],
$_POST['synopsis'],
$_POST['category'],
$_POST['status'],
$poster,
$banner,
$_POST['youtube_url'],
$_POST['release_date'],
$_POST['director'],
$_POST['producer'],
isset($_POST['featured'])?1:0,
$_POST['seo_title'],
$_POST['meta_description']

]);


header("Location:index.php");
exit;

}

?>

<h1>Add Advanced Production</h1>

<form method="post" enctype="multipart/form-data">

<input name="title" placeholder="Title">

<input name="slug" placeholder="Slug">

<textarea name="short_description" placeholder="Short Description"></textarea>

<textarea name="synopsis" placeholder="Full Synopsis"></textarea>

<input name="category" placeholder="Category">

<select name="status">
<option>Draft</option>
<option>Coming Soon</option>
<option>In Production</option>
<option>Post-Production</option>
<option>Released</option>
</select>

<input type="file" name="poster">

<input type="file" name="banner">

<input name="youtube_url" placeholder="YouTube URL">

<input name="release_date" type="date">

<input name="director" placeholder="Director">

<input name="producer" placeholder="Producer">

<label>
<input type="checkbox" name="featured">
Featured
</label>

<input name="seo_title" placeholder="SEO Title">

<textarea name="meta_description" placeholder="Meta Description"></textarea>

<button>Add Production</button>

</form>