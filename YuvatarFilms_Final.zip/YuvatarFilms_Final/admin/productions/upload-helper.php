<?php

function uploadImage($file){

    $allowed = ['jpg','jpeg','png','webp'];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if(!in_array($ext,$allowed)){
        return false;
    }

    $name = time().'_'.$file['name'];

    $path = "../../uploads/productions/".$name;

    if(move_uploaded_file($file['tmp_name'],$path)){
        return $name;
    }

    return false;
}

?>