<?php

require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

$db=new Database();
$pdo=$db->connect();

$id=$_GET['id'];

$stmt=$pdo->prepare("DELETE FROM productions WHERE id=?");
$stmt->execute([$id]);

header("Location:index.php");

exit;

?>