<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

$db=new Database();
$pdo=$db->connect();

$id=$_GET['id'];

$stmt=$pdo->prepare("SELECT * FROM productions WHERE id=?");
$stmt->execute([$id]);

$item=$stmt->fetch(PDO::FETCH_ASSOC);

if($_SERVER["REQUEST_METHOD"]=="POST"){

$stmt=$pdo->prepare(
"UPDATE productions SET title=?,status=?,category=? WHERE id=?"
);

$stmt->execute([
$_POST['title'],
$_POST['status'],
$_POST['category'],
$id
]);

header("Location:index.php");
exit;

}

?>

<h1>Edit Production</h1>

<form method="post">

<input name="title" value="<?=htmlspecialchars($item['title'])?>">

<input name="category" value="<?=htmlspecialchars($item['category'])?>">

<select name="status">
<option><?=htmlspecialchars($item['status'])?></option>
<option>Draft</option>
<option>Coming Soon</option>
<option>Released</option>
</select>

<button>Update</button>

</form>