<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

if($_POST){

$db=new Database();
$pdo=$db->connect();

$stmt=$pdo->prepare(
"INSERT INTO team_members
(name,designation,bio,display_order,status)
VALUES(?,?,?,?,?)"
);

$stmt->execute([
$_POST['name'],
$_POST['designation'],
$_POST['bio'],
$_POST['display_order'],
1
]);

header("Location:index.php");
exit;

}
?>

<h1>Add Team Member</h1>

<form method="post">

<input name="name" placeholder="Name">

<input name="designation" placeholder="Designation">

<textarea name="bio"></textarea>

<input name="display_order" value="0">

<button>Add</button>

</form>