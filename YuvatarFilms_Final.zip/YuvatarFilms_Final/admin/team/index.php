<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

$db=new Database();
$pdo=$db->connect();

$members=$pdo->query("SELECT * FROM team_members ORDER BY display_order ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Team Members</h1>

<a href="add.php">Add Member</a>

<?php foreach($members as $member): ?>

<div>
<h3><?=htmlspecialchars($member['name'])?></h3>
<p><?=htmlspecialchars($member['designation'])?></p>
</div>

<?php endforeach; ?>