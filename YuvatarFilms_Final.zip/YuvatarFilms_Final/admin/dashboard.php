<?php
require_once "../app/middleware/auth.php";
require_once "../app/config/database.php";

$db = new Database();
$pdo = $db->connect();

$productionCount = $pdo->query("SELECT COUNT(*) FROM productions")->fetchColumn();
$galleryCount = $pdo->query("SELECT COUNT(*) FROM gallery_albums")->fetchColumn();
$teamCount = $pdo->query("SELECT COUNT(*) FROM team_members")->fetchColumn();

?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard | Yuvatar Films</title>
<link rel="stylesheet" href="../assets/css/admin.css">
</head>

<body>

<div class="admin-layout">

<aside class="sidebar">

<h2>Yuvatar Films</h2>

<a href="dashboard.php">Dashboard</a>
<a href="productions/index.php">Productions</a>
<a href="gallery/albums.php">Gallery</a>
<a href="team/index.php">Team</a>
<a href="testimonials/index.php">Testimonials</a>
<a href="logout.php">Logout</a>

</aside>


<main class="dashboard">

<h1>Dashboard</h1>


<div class="stats">


<div class="stat-card">
<h3><?= $productionCount ?></h3>
<p>Total Productions</p>
</div>


<div class="stat-card">
<h3><?= $galleryCount ?></h3>
<p>Gallery Albums</p>
</div>


<div class="stat-card">
<h3><?= $teamCount ?></h3>
<p>Team Members</p>
</div>


<div class="stat-card">
<h3>0</h3>
<p>Draft Productions</p>
</div>


</div>


<div class="quick-actions">

<h2>Quick Actions</h2>

<a href="productions/add.php">
Add Production
</a>

<a href="gallery/add-album.php">
Add Gallery Album
</a>

</div>


<div class="recent">

<h2>Recent Updates</h2>

<p>No recent activity available.</p>

</div>


</main>

</div>

</body>
</html>