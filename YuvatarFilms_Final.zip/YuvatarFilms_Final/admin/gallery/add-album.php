<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$db=new Database();
$pdo=$db->connect();

$stmt=$pdo->prepare(
"INSERT INTO gallery_albums
(title,slug,description,status)
VALUES(?,?,?,?)"
);

$stmt->execute([
$_POST['title'],
$_POST['slug'],
$_POST['description'],
$_POST['status']
]);

header("Location:albums.php");
exit;

}
?>

<h1>Add Gallery Album</h1>

<form method="post">

<input name="title" placeholder="Album Title">

<input name="slug" placeholder="Slug">

<textarea name="description" placeholder="Description"></textarea>

<select name="status">
<option>Draft</option>
<option>Published</option>
</select>

<button>Add Album</button>

</form>