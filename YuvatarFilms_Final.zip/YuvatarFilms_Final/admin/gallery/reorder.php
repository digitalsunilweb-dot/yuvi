<?php

require_once "../../app/middleware/auth.php";

$order = $_POST['order'] ?? [];

foreach($order as $position=>$image){

    // Update display_order in database

}

echo "Order updated";

?>