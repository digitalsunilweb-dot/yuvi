<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

$db = new Database();
$pdo = $db->connect();

$albums = $pdo->query("SELECT * FROM gallery_albums ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Gallery Albums</h1>

<a href="add-album.php">Add Album</a>

<table border="1" cellpadding="10">
<tr>
<th>Title</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php foreach($albums as $album): ?>
<tr>
<td><?= htmlspecialchars($album['title']) ?></td>
<td><?= htmlspecialchars($album['status']) ?></td>
<td>
<a href="edit-album.php?id=<?= $album['id'] ?>">Edit</a>
<a href="images.php?id=<?= $album['id'] ?>">Images</a>
</td>
</tr>
<?php endforeach; ?>

</table>