<?php
require_once "../../app/middleware/auth.php";
?>

<h1>Album Images</h1>

<form method="post" enctype="multipart/form-data">

<input type="file" name="images[]" multiple>

<input name="caption" placeholder="Caption">

<input name="alt_text" placeholder="Alt Text">

<button>Upload Images</button>

</form>