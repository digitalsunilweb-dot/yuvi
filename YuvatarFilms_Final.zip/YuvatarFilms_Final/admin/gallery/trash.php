<?php

require_once "../../app/middleware/auth.php";

// Soft delete structure.
// Add deleted_at column and restore workflow.

echo "Moved to trash";

?>