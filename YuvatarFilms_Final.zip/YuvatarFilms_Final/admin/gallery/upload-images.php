<?php
require_once "../../app/middleware/auth.php";

function validateImage($file){

    $allowed = ['jpg','jpeg','png','webp'];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    return in_array($ext,$allowed);

}

if($_SERVER['REQUEST_METHOD']=="POST"){

    foreach($_FILES['images']['tmp_name'] as $key=>$tmp){

        if(validateImage([
            'name'=>$_FILES['images']['name'][$key]
        ])){

            $name=time().'_'.$key.'_'.$_FILES['images']['name'][$key];

            move_uploaded_file(
                $tmp,
                "../../uploads/gallery/".$name
            );

        }

    }

    echo "Images uploaded";

}

?>