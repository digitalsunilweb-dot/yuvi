<?php
session_start();

require_once "../app/config/database.php";

$message = "";

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $db = new Database();
    $pdo = $db->connect();

    $stmt = $pdo->prepare(
        "SELECT * FROM admin_users WHERE username=? AND status=1 LIMIT 1"
    );

    $stmt->execute([$username]);

    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if($admin && password_verify($password,$admin['password_hash'])){

        session_regenerate_id(true);

        $_SESSION['admin_id']=$admin['id'];
        $_SESSION['admin_role']=$admin['role'];

        header("Location: dashboard.php");
        exit;

    }else{

        $message="Invalid login details";

    }

}

?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login | Yuvatar Films</title>
<link rel="stylesheet" href="../assets/css/admin.css">
</head>

<body>

<div class="login-box">

<h2>Yuvatar Films Admin</h2>

<p><?= $message ?></p>

<form method="post">

<input type="text" name="username" placeholder="Username" required>

<input type="password" name="password" placeholder="Password" required>

<button type="submit">
Login
</button>

</form>

</div>

</body>
</html>