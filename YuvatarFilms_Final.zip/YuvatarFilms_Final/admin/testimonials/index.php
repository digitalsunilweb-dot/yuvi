<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

$db=new Database();
$pdo=$db->connect();

$data=$pdo->query("SELECT * FROM testimonials ORDER BY display_order")->fetchAll(PDO::FETCH_ASSOC);

?>

<h1>Testimonials</h1>

<a href="add.php">Add Testimonial</a>

<?php foreach($data as $item): ?>

<div>
<h3><?=htmlspecialchars($item['name'])?></h3>
<p><?=htmlspecialchars($item['testimonial'])?></p>
</div>

<?php endforeach; ?>