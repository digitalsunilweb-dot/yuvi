<?php
require_once "../../app/middleware/auth.php";
require_once "../../app/config/database.php";

if($_POST){

$db=new Database();
$pdo=$db->connect();

$stmt=$pdo->prepare(
"INSERT INTO testimonials
(name,company,testimonial,status)
VALUES(?,?,?,1)"
);

$stmt->execute([
$_POST['name'],
$_POST['company'],
$_POST['testimonial']
]);

header("Location:index.php");
exit;

}
?>

<h1>Add Testimonial</h1>

<form method="post">

<input name="name" placeholder="Name">

<input name="company" placeholder="Company">

<textarea name="testimonial"></textarea>

<button>Add</button>

</form>